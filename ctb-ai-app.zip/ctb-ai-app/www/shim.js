/* Used by the Android/iOS/desktop app. Provides the AI + save-file features by
   talking to YOUR CTB server (see server/). Skipped if the host already provides them. */
(function () {
  if (window.claude) return;
  const base = () => { try { return (localStorage.getItem('ctb_server') || '').replace(/^ws/, 'http').replace(/\/$/, ''); } catch (e) { return ''; } };
  async function call(input) {
    const b = base();
    if (!b) throw { code: 'not_granted', message: 'Enter your CTB server URL in Secure Chat first.' };
    const r = await fetch(b + '/ai', { method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ messages: typeof input === 'string' ? [{ role: 'user', content: input }] : input }) });
    const d = await r.json();
    if (!r.ok) throw { code: 'error', message: d.error || 'AI error' };
    return { text: d.text, truncated: false };
  }
  async function sample(input, opts) { const r = await call(input); if (opts && opts.onText) opts.onText({ text: r.text, delta: r.text }); return r; }
  sample.json = async (input) => JSON.parse((await call(input)).text.replace(/```json|```/g, '').trim());
  const downloads = { save: async ({ filename, data }) => { const a = document.createElement('a'); a.href = URL.createObjectURL(data); a.download = filename; a.click(); } };
  window.claude = { use: async (n) => ({ sample, downloads })[n] || null };
})();
