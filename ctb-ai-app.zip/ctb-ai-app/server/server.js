// CTB server: (1) end-to-end-encrypted chat relay, (2) AI proxy that keeps your API key off the phone.
// The relay never sees keys or plaintext: clients encrypt before sending. Nothing is stored.
const http = require('http');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 8080;
const KEY = process.env.CTB_API_KEY || '';
const MODEL = process.env.CTB_MODEL || 'claude-sonnet-5-5';
const rooms = new Map();
const hits = new Map(); // crude per-IP rate limit for /ai
const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'content-type', 'access-control-allow-methods': 'POST,OPTIONS' };

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  if (req.method === 'POST' && req.url === '/ai') {
    const ip = req.socket.remoteAddress, now = Date.now();
    const h = (hits.get(ip) || []).filter(t => now - t < 60000);
    if (h.length >= 20) { res.writeHead(429, cors); return res.end(JSON.stringify({ error: 'Slow down' })); }
    h.push(now); hits.set(ip, h);
    let body = ''; req.on('data', c => { body += c; if (body.length > 200000) req.destroy(); });
    req.on('end', async () => {
      try {
        if (!KEY) throw new Error('Server has no CTB_API_KEY set');
        const { messages } = JSON.parse(body);
        const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({ model: MODEL, max_tokens: 4000, messages }) });
        const d = await r.json();
        if (!r.ok) throw new Error(d.error?.message || 'API error');
        res.writeHead(200, { ...cors, 'content-type': 'application/json' });
        res.end(JSON.stringify({ text: d.content.map(c => c.text || '').join('') }));
      } catch (e) { res.writeHead(500, { ...cors, 'content-type': 'application/json' }); res.end(JSON.stringify({ error: e.message })); }
    });
    return;
  }
  res.writeHead(200, { 'content-type': 'text/plain' }); res.end('CTB server running');
});

const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });
wss.on('connection', (ws, req) => {
  const room = new URL(req.url, 'http://x').searchParams.get('room') || '';
  if (!/^[a-z0-9]{4,64}$/.test(room)) return ws.close();
  if (!rooms.has(room)) rooms.set(room, new Set());
  const set = rooms.get(room); set.add(ws);
  ws.on('message', data => { for (const peer of set) if (peer !== ws && peer.readyState === 1) peer.send(data.toString()); });
  ws.on('close', () => { set.delete(ws); if (!set.size) rooms.delete(room); });
});
server.listen(PORT, () => console.log('CTB server on :' + PORT));
