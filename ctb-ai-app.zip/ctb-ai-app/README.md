# CTB AI

Chat, Autopilot agent, sudo-style sandbox terminal, Music, Design, Video, and end-to-end-encrypted Secure Chat.

## 1. Run the server (needed for the apps' encrypted chat and AI)
    cd server && npm install
    CTB_API_KEY=your_key npm start        # Windows PowerShell: $env:CTB_API_KEY="your_key"; npm start
Put it on any host with HTTPS (Render, Fly.io, Railway, a VPS). Phones require secure `wss://` URLs.
In the app, open Secure Chat and enter e.g. `wss://your-server.example.com` once.

## 2. Android (APK)
Easiest, no Android Studio: push this folder to a GitHub repo, open the Actions tab, run "Build Android APK",
and download `ctb-ai-apk` (a debug APK you can install on your phone).
Or locally: `npm install && npx cap add android && npx cap sync android && npx cap open android`, then Build > Build APK.
For the Play Store you need a signed release build and a Google Play developer account (one-time $25).

## 3. iPhone / iPad (iOS)
Apple only allows iOS builds on a Mac with Xcode and an Apple Developer account ($99/year):
    npm install && npx cap add ios && npx cap sync ios && npx cap open ios
In Xcode choose your team, run on your device, then Product > Archive to send to TestFlight / the App Store.

## 4. Desktop
    npm install && npm start
    npm run build:win   (or build:mac / build:linux)

## How the encryption works
Each session, every device makes a fresh ECDH P-256 key pair. Two people derive a shared AES-256-GCM key
from each other's public keys, and every message is encrypted separately for each person in the room. The server
only relays ciphertext. To rule out a man-in-the-middle, compare each other's "safety number" (key fingerprint)
by voice or in person. Limits: no message history, no offline delivery, and no Signal-style ratcheting; metadata
(who is in which room, and when) is visible to the server operator.
